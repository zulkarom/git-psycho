<!doctype html>
<html>
<head>
    <title>UJIAN PSIKOMETRIK :: FACULTY OF ENTREPRENEURSHIP AND BUSINESS</title>
    <!-- META -->
    <meta charset="utf-8">
    <!-- send empty favicon fallback to prevent user's browser hitting the server for lots of favicon requests resulting in 404s -->
    <link rel="icon" href="data:;base64,=">
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo Config::get('URL'); ?>css/style.css" />
	<link rel="stylesheet" href="<?php echo Config::get('URL'); ?>bootstrap/css/bootstrap.css" />
	<script src='<?php echo Config::get('URL'); ?>js/jquery/core/jquery.min.js'></script>
	
	<script type="text/javascript" src="<?php echo Config::get('URL'); ?>excel/dist/xlsx.core.min.js"></script>
<script type="text/javascript" src="<?php echo Config::get('URL'); ?>excel/dist/FileSaver.js"></script>
	
	
	<style>
	.shadow{
	box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.2), 0 3px 10px 0 rgba(0, 0, 0, 0.19);	
	}
	</style>
</head>
<body>
    <!-- wrapper, to center website -->
    <div >
