<!doctype html>
<html>
<head>
    <title>ONLINE INTERVIEW - 2U2I :: FACULTY OF ENTREPRENEURSHIP AND BUSINESS</title>
    <!-- META -->
    <meta charset="utf-8">
    <!-- send empty favicon fallback to prevent user's browser hitting the server for lots of favicon requests resulting in 404s -->
    <link rel="icon" href="data:;base64,=">
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo Config::get('URL'); ?>css/style.css" />
	<link rel="stylesheet" href="<?php echo Config::get('URL'); ?>bootstrap/css/bootstrap.css" />
	<script src='<?php echo Config::get('URL'); ?>js/jquery/core/jquery.min.js'></script>
	<script src='<?php echo Config::get('URL'); ?>bootstrap/js/bootstrap.js'></script>
	
	<style>
		
	.sfile{
	width:300px;
	}

	.fileUpload {
		position: relative;
		overflow: hidden;
		width:300px;
		margin: 0 auto;
		text-align:center;
	}
	.fileUpload input.upload {
		position: absolute;
		top: 0;
		right: 0;
		margin: 0 ;
		padding: 0;
		font-size: 20px;
		cursor: pointer;
		opacity: 0;
		filter: alpha(opacity=0);
	}

	</style>
</head>
<body>
    <!-- wrapper, to center website -->
    <div class="wrapperadmin">





     
        